"""
styles.py
=========
All custom CSS for the Streamlit app.
Kept separate so app.py stays clean.
"""

CUSTOM_CSS = """
<style>

/* ── Google Fonts ── */
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Nunito:wght@400;600;700;800&display=swap');

/* ── Root variables ── */
:root {
    --bg:       #0d1117;
    --surface:  #161b22;
    --card:     #1c2130;
    --border:   #30363d;
    --accent:   #58a6ff;
    --purple:   #bc8cff;
    --green:    #3fb950;
    --yellow:   #d29922;
    --red:      #f85149;
    --text:     #e6edf3;
    --muted:    #8b949e;
    --mono:     'Space Mono', monospace;
    --sans:     'Nunito', sans-serif;
}

/* ── Base ── */
.stApp {
    background-color: var(--bg) !important;
}
section[data-testid="stSidebar"] {
    background-color: var(--surface) !important;
    border-right: 1px solid var(--border) !important;
}
p, li, span, div {
    font-family: var(--sans) !important;
    color: var(--text);
}
h1, h2, h3, h4 {
    font-family: var(--mono) !important;
}

/* ── Sidebar labels & inputs ── */
label[data-testid="stWidgetLabel"] p {
    color: var(--text) !important;
    font-weight: 600 !important;
    font-size: 0.85rem !important;
}
input[type="number"], input[type="text"], textarea {
    background-color: var(--card) !important;
    border: 1px solid var(--border) !important;
    color: var(--text) !important;
    border-radius: 6px !important;
    font-family: var(--mono) !important;
    font-size: 0.85rem !important;
}

/* ── Primary button ── */
div[data-testid="stButton"] > button[kind="primary"],
div[data-testid="stButton"] > button {
    background: linear-gradient(135deg, #1f6feb, #8957e5) !important;
    color: #ffffff !important;
    border: none !important;
    border-radius: 8px !important;
    font-family: var(--mono) !important;
    font-weight: 700 !important;
    font-size: 0.9rem !important;
    padding: 0.6rem 1.5rem !important;
    width: 100% !important;
    cursor: pointer !important;
    transition: opacity .2s !important;
}
div[data-testid="stButton"] > button:hover {
    opacity: 0.85 !important;
}

/* ── Expander ── */
div[data-testid="stExpander"] {
    background-color: var(--surface) !important;
    border: 1px solid var(--border) !important;
    border-radius: 10px !important;
}

/* ── Dataframe ── */
div[data-testid="stDataFrame"] {
    background-color: var(--card) !important;
    border-radius: 8px !important;
    border: 1px solid var(--border) !important;
}

/* ── Streamlit default text overrides ── */
.stMarkdown h1 { color: var(--accent) !important; }
.stMarkdown h2 { color: var(--text)   !important; }
.stMarkdown h3 { color: var(--muted)  !important; }

/* ── Custom component classes ── */
.hero-banner {
    background: linear-gradient(135deg, #161b22 0%, #1c2130 60%, #1a1f35 100%);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 1.8rem 2rem;
    margin-bottom: 1.6rem;
}
.hero-title {
    font-family: var(--mono);
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--accent);
    margin: 0 0 0.3rem;
}
.hero-sub {
    color: var(--muted);
    font-family: var(--sans);
    font-size: 0.92rem;
    margin: 0 0 0.8rem;
}
.badge {
    display: inline-block;
    background: rgba(88,166,255,.12);
    border: 1px solid rgba(88,166,255,.3);
    color: var(--accent);
    font-family: var(--mono);
    font-size: 0.68rem;
    padding: 2px 9px;
    border-radius: 20px;
    margin-right: 5px;
}

.metric-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 0.8rem;
    margin: 1rem 0 1.4rem;
}
.metric-box {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 0.9rem 1rem;
}
.metric-label {
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    color: var(--muted);
    margin-bottom: 0.3rem;
    font-family: var(--sans);
}
.metric-value {
    font-family: var(--mono);
    font-size: 1.4rem;
    font-weight: 700;
}
.c-green  { color: var(--green)  !important; }
.c-blue   { color: var(--accent) !important; }
.c-yellow { color: var(--yellow) !important; }
.c-purple { color: var(--purple) !important; }

.section-box {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 1.2rem 1.5rem;
    margin-bottom: 1.2rem;
}
.section-heading {
    font-family: var(--mono);
    font-size: 0.9rem;
    font-weight: 700;
    color: var(--accent);
    border-bottom: 1px solid var(--border);
    padding-bottom: 0.5rem;
    margin-bottom: 0.9rem;
}

.info-block {
    background: rgba(88,166,255,.07);
    border-left: 3px solid var(--accent);
    border-radius: 0 6px 6px 0;
    padding: 0.7rem 0.9rem;
    margin: 0.5rem 0;
    font-size: 0.88rem;
}
.warn-block {
    background: rgba(210,153,34,.08);
    border-left: 3px solid var(--yellow);
    border-radius: 0 6px 6px 0;
    padding: 0.7rem 0.9rem;
    margin: 0.5rem 0;
    font-size: 0.88rem;
}
.good-block {
    background: rgba(63,185,80,.08);
    border-left: 3px solid var(--green);
    border-radius: 0 6px 6px 0;
    padding: 0.7rem 0.9rem;
    margin: 0.5rem 0;
    font-size: 0.88rem;
}

.tl-wrap  { display: flex; flex-wrap: wrap; gap: 4px; margin: 0.6rem 0; }
.tl-chip {
    min-width: 56px;
    padding: 6px 8px;
    text-align: center;
    border: 1px solid var(--border);
    border-radius: 6px;
    font-family: var(--mono);
    font-size: 0.73rem;
    color: var(--muted);
    background: var(--surface);
    line-height: 1.4;
}
.tl-chip.active {
    background: rgba(88,166,255,.15);
    border-color: var(--accent);
    color: var(--accent);
    font-weight: 700;
}

.step-row { display: flex; gap: 0.6rem; align-items: flex-start; margin: 0.4rem 0; }
.step-dot {
    min-width: 24px; height: 24px;
    background: var(--accent);
    color: #0d1117;
    border-radius: 50%;
    font-family: var(--mono);
    font-size: 0.7rem;
    font-weight: 700;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}
.step-txt { font-size: 0.88rem; padding-top: 3px; line-height: 1.5; }

.formula-box {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 0.9rem 1.1rem;
    font-family: var(--mono);
    font-size: 0.8rem;
    line-height: 1.9;
    color: var(--text);
    margin: 0.4rem 0;
}
</style>
"""
