"""
dp_solver.py
============
Core Dynamic Programming algorithm for inventory cost optimization.

PROBLEM:
    Given N days of demand, find WHEN to restock and HOW MUCH to order
    so that (Ordering Cost + Holding Cost) is MINIMIZED.

STATE:
    dp[i] = minimum total cost from day i to day N-1,
            assuming we start day i with 0 inventory and MUST order on day i.

TRANSITION:
    From day i, try ordering enough to cover days i..j-1 (next restock on day j):
        cost = ordering_cost
             + sum of holding costs over days i..j-1
             + dp[j]   (optimal cost from day j onwards)
    dp[i] = min over all valid j

BASE CASE:
    dp[N] = 0  (no days left, zero cost)

TIME COMPLEXITY:  O(N^2)
SPACE COMPLEXITY: O(N)

WHY GREEDY FAILS:
    Greedy orders only for today → pays ordering_cost every day.
    DP can see that bulk-ordering today (extra holding cost) is cheaper
    than paying ordering_cost repeatedly. Greedy can't see the future.
"""


def build_prefix(demands):
    """
    Build prefix sum array so range sums are O(1).
    prefix[i+1] - prefix[i] == demands[i]
    """
    n = len(demands)
    prefix = [0] * (n + 1)
    for i in range(n):
        prefix[i + 1] = prefix[i] + demands[i]
    return prefix


def holding_cost_range(prefix, i, j, h):
    """
    Compute total holding cost when we order on day i to cover days i..j-1.

    On day k (i <= k < j):
        stock_at_end_of_day_k = total_ordered - demand already consumed
                               = (prefix[j] - prefix[i]) - (prefix[k+1] - prefix[i])
                               = prefix[j] - prefix[k+1]
    Total holding cost = sum over k of (stock_at_end_of_day_k * h)
    """
    qty = prefix[j] - prefix[i]   # total ordered on day i
    total_hold = 0.0
    for k in range(i, j):
        stock_end = qty - (prefix[k + 1] - prefix[i])
        total_hold += stock_end * h
    return round(total_hold, 4)


def run_dp(demands, ordering_cost, holding_cost_per_unit):
    """
    Main DP tabulation (bottom-up, right to left).

    Returns
    -------
    dp          : list[float]  dp[i] = min cost from day i to end
    next_order  : list[int]    next_order[i] = next restock day after i
    table_rows  : list[dict]   every (i,j) evaluation — for UI display
    """
    n      = len(demands)
    prefix = build_prefix(demands)

    dp         = [float('inf')] * (n + 1)
    next_order = [-1]           * (n + 1)
    dp[n]      = 0.0             # base case

    table_rows = []   # collect every evaluated state for display

    # Fill right → left
    for i in range(n - 1, -1, -1):
        for j in range(i + 1, n + 1):
            qty  = prefix[j] - prefix[i]
            hold = holding_cost_range(prefix, i, j, holding_cost_per_unit)
            fut  = dp[j]
            tot  = ordering_cost + hold + fut

            table_rows.append({
                "From Day (i)":        i + 1,
                "Next Restock (j)":    (j + 1) if j < n else "END",
                "Order Qty":           qty,
                "Ordering Cost (₹)":   round(ordering_cost, 2),
                "Holding Cost (₹)":    round(hold, 2),
                "Future Cost dp[j] (₹)": round(fut, 2) if fut != float('inf') else "∞",
                "Total Candidate (₹)": round(tot, 2) if tot != float('inf') else "∞",
            })

            if tot < dp[i]:
                dp[i]         = tot
                next_order[i] = j

    return dp, next_order, table_rows


def reconstruct_plan(demands, next_order):
    """
    Trace next_order[] to build the optimal restocking schedule.

    Returns list of dicts: {day, order_qty, covers}
    """
    n      = len(demands)
    prefix = build_prefix(demands)
    plan   = []
    day    = 0

    while day < n:
        j   = next_order[day]
        qty = prefix[j] - prefix[day]
        plan.append({
            "Order Day":      day + 1,
            "Order Qty (units)": qty,
            "Covers Days":    f"Day {day + 1} → Day {j}",
        })
        day = j

    return plan


def build_full_day_table(demands, next_order):
    """
    Build a per-day table showing Planning Day, Demand, Action, Order Quantity,
    Inventory Level (end of day), and which order batch each day belongs to.

    This is the main output table shown to the user.
    """
    n      = len(demands)
    prefix = build_prefix(demands)
    rows   = []

    # Pre-compute which days have an order and how much
    order_map = {}   # day_index -> qty ordered
    day = 0
    while day < n:
        j   = next_order[day]
        qty = prefix[j] - prefix[day]
        order_map[day] = qty
        day = j

    # Walk through every day and compute inventory level
    inventory = 0
    for i in range(n):
        if i in order_map:
            inventory += order_map[i]
            action    = "ORDER"
            order_qty = order_map[i]
        else:
            action    = "-"
            order_qty = 0

        inventory -= demands[i]   # consume today's demand

        rows.append({
            "Planning Day":    i + 1,
            "Demand":          demands[i],
            "Action":          action,
            "Order Quantity":  order_qty,
            "Inventory (End)": inventory,
        })

    return rows


def naive_greedy_cost(demands, ordering_cost):
    """
    Naive greedy: order exactly today's demand every single day.
    Cost = ordering_cost * N  (zero holding cost, maximum ordering cost)
    """
    return round(ordering_cost * len(demands), 2)


def dp_summary(dp, next_order, demands):
    """Build a clean dp[] display table."""
    n = len(demands)
    rows = []
    for i in range(n):
        rows.append({
            "Day":            i + 1,
            "Demand":         demands[i],
            "dp[i] (₹)":      round(dp[i], 2),
            "Next Order Day": (next_order[i] + 1) if next_order[i] < n else "END",
        })
    return rows
