"""
sidebar.py
==========
Handles all Streamlit sidebar input widgets.
Returns a dict of validated user inputs.
"""

import streamlit as st


def render_sidebar():
    """
    Renders sidebar inputs and returns a dict:
    {
        'n_days':         int,
        'demands':        list[int] or None,
        'ordering_cost':  float,
        'holding_cost':   float,
        'calculate':      bool,
        'error':          str or None,
    }
    """
    with st.sidebar:
        st.markdown(
            "<div style='font-family:Space Mono;font-size:1rem;"
            "color:#58a6ff;font-weight:700;margin-bottom:0.3rem;'>"
            "⚙️ Input Parameters</div>"
            "<div style='color:#8b949e;font-size:0.78rem;margin-bottom:1rem;'>"
            "Fill in your inventory scenario.</div>",
            unsafe_allow_html=True
        )

        # ── Number of days ──
        n_days = st.number_input(
            "📅 Number of Days",
            min_value=2, max_value=20, value=6, step=1,
            help="Planning horizon: how many days to optimize (2–20)"
        )

        # ── Daily demand ──
        demand_str = st.text_input(
            "📦 Daily Demand (comma-separated)",
            value="10, 20, 15, 10, 25, 5",
            help="Enter one integer demand per day, separated by commas"
        )

        # ── Ordering cost ──
        ordering_cost = st.number_input(
            "🛒 Ordering Cost (₹ per order)",
            min_value=1.0, max_value=99999.0,
            value=50.0, step=5.0,
            help="Fixed cost charged every time you place a restock order"
        )

        # ── Holding cost ──
        holding_cost = st.number_input(
            "🏪 Holding Cost (₹ per unit per day)",
            min_value=0.01, max_value=999.0,
            value=1.0, step=0.1,
            help="Cost of storing one unit of inventory for one day"
        )

        st.markdown("---")

        calculate = st.button("🚀 Calculate Optimal Restock Plan")

        # Info footer
        st.markdown(
            "<div style='margin-top:1.2rem;color:#484f58;font-size:0.72rem;"
            "font-family:Space Mono;line-height:1.7;'>"
            "<b style='color:#58a6ff;'>Algorithm:</b> DP Tabulation<br>"
            "<b style='color:#58a6ff;'>Complexity:</b> O(N²)<br>"
            "<b style='color:#58a6ff;'>Goal:</b> Min Ordering + Holding Cost"
            "</div>",
            unsafe_allow_html=True
        )

    # ── Validate demand string ──
    demands = None
    error   = None

    try:
        demands = [int(x.strip()) for x in demand_str.split(",") if x.strip()]
    except ValueError:
        error = "❌ Invalid demand values. Use integers separated by commas (e.g. 10, 20, 15)."

    if demands is not None:
        if len(demands) != n_days:
            error = (
                f"❌ You entered {len(demands)} demand value(s) "
                f"but set {n_days} days. They must match."
            )
        elif any(d <= 0 for d in demands):
            error = "❌ All demand values must be positive integers (> 0)."

    return {
        "n_days":        n_days,
        "demands":       demands,
        "ordering_cost": ordering_cost,
        "holding_cost":  holding_cost,
        "calculate":     calculate,
        "error":         error,
    }
