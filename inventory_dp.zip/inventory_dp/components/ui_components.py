"""
ui_components.py
================
Reusable HTML/CSS component builders for the Streamlit app.
Each function returns an HTML string that can be rendered with
st.markdown(..., unsafe_allow_html=True).
"""

def hero_banner():
    """Top hero section with title and badges."""
    return """
    <div class="hero-banner">
        <div class="hero-title">📦 Inventory Management System</div>
        <div class="hero-sub">Cost Optimization using Dynamic Programming</div>
        <div>
            <span class="badge">Dynamic Programming</span>
            <span class="badge">Tabulation</span>
            <span class="badge">O(N²)</span>
            <span class="badge">Python · Streamlit</span>
        </div>
    </div>
    """


def metric_cards(dp_cost, naive_cost, savings, n_orders):
    """Four metric cards showing key results."""
    return f"""
    <div class="metric-grid">
        <div class="metric-box">
            <div class="metric-label">DP Min Cost</div>
            <div class="metric-value c-green">₹{dp_cost}</div>
        </div>
        <div class="metric-box">
            <div class="metric-label">Naive Greedy Cost</div>
            <div class="metric-value c-yellow">₹{naive_cost}</div>
        </div>
        <div class="metric-box">
            <div class="metric-label">Cost Saved by DP</div>
            <div class="metric-value c-blue">₹{savings}</div>
        </div>
        <div class="metric-box">
            <div class="metric-label">Restock Orders</div>
            <div class="metric-value c-purple">{n_orders}</div>
        </div>
    </div>
    """


def restock_timeline(n_days, restock_days_set):
    """
    Visual day-by-day timeline highlighting restock days.
    restock_days_set: set of 1-indexed day numbers that have an order.
    """
    chips = ""
    for d in range(1, n_days + 1):
        cls  = "tl-chip active" if d in restock_days_set else "tl-chip"
        icon = "📥" if d in restock_days_set else ""
        chips += f'<div class="{cls}">D{d}<br>{icon}</div>'

    return f"""
    <div class="section-box">
        <div class="section-heading">📅 Restocking Timeline</div>
        <div class="tl-wrap">{chips}</div>
        <div style="color:#8b949e;font-size:0.75rem;margin-top:0.3rem;">
            📥 = restock order placed on this day
        </div>
    </div>
    """


def plan_steps(plan):
    """Numbered step list for the restocking plan."""
    steps_html = ""
    for i, p in enumerate(plan):
        steps_html += f"""
        <div class="step-row">
            <div class="step-dot">{i+1}</div>
            <div class="step-txt">
                <b>Day {p['Order Day']}:</b>
                Order <b>{p['Order Qty (units)']} units</b>
                &nbsp;—&nbsp; covers {p['Covers Days']}
            </div>
        </div>"""
    return f"""
    <div class="section-box">
        <div class="section-heading">✅ Optimal Restocking Plan</div>
        {steps_html}
    </div>
    """


def dp_vs_naive_cards(ordering_cost, n_days, n_orders, dp_cost, naive_cost, savings):
    """Side-by-side comparison of greedy vs DP."""
    return f"""
    <div class="section-box">
        <div class="section-heading">⚖️ DP vs Naive Greedy Comparison</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
            <div class="warn-block">
                <b>🐢 Naive Greedy</b><br><br>
                Strategy: Order today's demand every day.<br>
                Orders placed: <b>{n_days}</b><br>
                Ordering cost: ₹{ordering_cost} × {n_days} = ₹{round(ordering_cost * n_days, 2)}<br>
                Holding cost: ₹0<br><br>
                <b>Total: ₹{naive_cost}</b>
            </div>
            <div class="good-block">
                <b>🚀 Dynamic Programming</b><br><br>
                Strategy: Find globally optimal schedule.<br>
                Orders placed: <b>{n_orders}</b><br>
                Balances ordering vs holding cost optimally.<br>
                Uses memoized subproblem results.<br><br>
                <b>Total: ₹{dp_cost}</b> &nbsp;💰 saves ₹{savings}
            </div>
        </div>
    </div>
    """


def welcome_explainer():
    """Shown before user hits Calculate."""
    return """
    <div class="section-box">
        <div class="section-heading">🧠 How This App Works</div>

        <div class="info-block">
            Given daily demand for a product over N days, this app finds the
            <b>cheapest restocking schedule</b> using Dynamic Programming —
            deciding <em>when</em> to order and <em>how much</em> each time.
        </div>

        <div style="margin-top:0.9rem;">
            <div class="step-row">
                <div class="step-dot">1</div>
                <div class="step-txt">Enter number of days and daily demand in the sidebar.</div>
            </div>
            <div class="step-row">
                <div class="step-dot">2</div>
                <div class="step-txt">Set ordering cost (paid each restock) and holding cost (per unit/day).</div>
            </div>
            <div class="step-row">
                <div class="step-dot">3</div>
                <div class="step-txt">Click <b>"Calculate Optimal Restock Plan"</b> for results.</div>
            </div>
        </div>
    </div>

    <div class="section-box">
        <div class="section-heading">📐 DP Formulation</div>
        <div class="formula-box">
<span style="color:#58a6ff;font-weight:700;">State:</span>
  dp[i] = min total cost from day i → end
          (starting with 0 stock, must order on day i)

<span style="color:#58a6ff;font-weight:700;">Transition:</span>
  dp[i] = min over j &gt; i of:
            ordering_cost
          + holding_cost(i, j)
          + dp[j]

<span style="color:#58a6ff;font-weight:700;">Base Case:</span>
  dp[N] = 0   (no days left → zero cost)

<span style="color:#58a6ff;font-weight:700;">Complexity:</span>  O(N²) time  |  O(N) space
        </div>
    </div>

    <div class="section-box">
        <div class="section-heading">🚫 Why Greedy Fails</div>
        <div class="warn-block">
            <b>Greedy idea:</b> "Order only what's needed today."<br>
            <b>Problem:</b> Pays ordering cost EVERY day — ignores future.
            DP sees that paying a little extra holding cost today avoids
            repeated ordering costs tomorrow. Greedy is locally optimal,
            DP is globally optimal.
        </div>
    </div>
    """


def viva_section(dp_cost, n_days):
    """Viva prep theory section."""
    return f"""
    <div class="section-box">
        <div class="section-heading">📚 Problem & Algorithm</div>
        <div style="font-size:0.88rem;line-height:1.8;">
            <b style="color:#58a6ff;">Problem:</b>
            Given N-day demand, find restock days & quantities to minimize
            Ordering Cost + Holding Cost.<br><br>

            <b style="color:#58a6ff;">Why not Greedy?</b>
            Greedy only looks at today. If ordering_cost is high, it's
            cheaper to bulk-order now (slight holding overhead) than to
            order repeatedly. Greedy cannot evaluate future impact.<br><br>

            <b style="color:#58a6ff;">DP Advantage:</b>
            Breaks problem into subproblems dp[i..N]. Stores results
            so each subproblem is solved once (tabulation). Guarantees
            global optimum by exhaustive comparison of all valid choices.<br><br>

            <b style="color:#58a6ff;">State:</b>
            dp[i] = min cost from day i to day {n_days}, start with 0 stock.<br><br>

            <b style="color:#58a6ff;">Transition:</b>
            dp[i] = min_j [ ordering_cost + HoldingCost(i,j) + dp[j] ]<br><br>

            <b style="color:#58a6ff;">Time Complexity:</b>
            O(N²) — N starting days × N choices of next order day.
            Brute-force would be O(2^N). DP is exponentially faster.<br><br>

            <b style="color:#58a6ff;">Space Complexity:</b>
            O(N) for dp[] and next_order[] arrays.<br><br>

            <b style="color:#58a6ff;">Final Answer:</b>
            dp[1] = ₹{dp_cost} is the minimum possible total cost.
        </div>
    </div>
    """
